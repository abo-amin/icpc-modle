using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace icpc_modle.Views.Exam
{
    public class FinishModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
